# EmailVerificationUsingJSPServlet
create database fname,lname,email,pword,hash and active column which have default value 0.
database dumb file is available within database folder, just import it
