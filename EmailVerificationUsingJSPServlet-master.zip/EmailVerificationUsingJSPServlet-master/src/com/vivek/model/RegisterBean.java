package com.vivek.model;

public class RegisterBean {
	
	private String fname;
	private String lname;
	private String email;
	private String pword;
	private String myHash;
	/**
	 * @return the fname
	 */
	public String getFname() {
		return fname;
	}
	/**
	 * @param fname the fname to set
	 */
	public void setFname(String fname) {
		this.fname = fname;
	}
	/**
	 * @return the lname
	 */
	public String getLname() {
		return lname;
	}
	/**
	 * @param lname the lname to set
	 */
	public void setLname(String lname) {
		this.lname = lname;
	}
	/**
	 * @return the email
	 */
	public String getEmail() {
		return email;
	}
	/**
	 * @param email the email to set
	 */
	public void setEmail(String email) {
		this.email = email;
	}
	/**
	 * @return the pword
	 */
	public String getPword() {
		return pword;
	}
	/**
	 * @param pword the pword to set
	 */
	public void setPword(String pword) {
		this.pword = pword;
	}
	/**
	 * @return the myhash
	 */
	/**
	 * @return the myHash
	 */
	public String getMyHash() {
		return myHash;
	}
	/**
	 * @param myHash the myHash to set
	 */
	public void setMyHash(String myHash) {
		this.myHash = myHash;
	}
	
	

}
